# read the dataset
telecom<-read.csv("telecom.csv")


###################################################
###### Simple visualization of data ###############
###################################################

# skim this dataset
library("skimr")
skim(telecom)

# simple visualisations of the data
DataExplorer::plot_bar(telecom, ncol = 3)
DataExplorer::plot_histogram(telecom, ncol = 3)
DataExplorer::plot_boxplot(telecom, by = "Churn", ncol = 3)

#####################################################
######### DATA Processing before modeling############
#####################################################

# turn the class of all columns from 'character' to 'factor': 
telecom<-telecom%>%
  mutate(Senior_Citizen=case_when(
    SeniorCitizen==0~'No',
    TRUE~"Yes"
  ))%>%
  select(-SeniorCitizen)

loops<-dim(telecom)[2]
for (i in 1:loops){
  telecom[,i]<-as.factor(telecom[,i])
}

###############################################################################
###################### MLR3 Model fitting #####################################
###############################################################################

################## Part 1: try to fit different models:########################

library("tidyverse")
library("mlr3")
library("mlr3verse")
library("data.table")


# define a task:
set.seed(20)
telecom_task <- TaskClassif$new(id = "Telecom",
                              backend = telecom, 
                              target = "Churn",
                              positive = "No")

# constructs a resampling strategy and set cross validation with 5 folds
cv5 <- rsmp("cv", folds = 5)
cv5$instantiate(telecom_task)


# define models using 'featureless' and 'rpart':
lrn_baseline_tel <- lrn("classif.featureless", predict_type = "prob")
lrn_cart_tel <- lrn("classif.rpart", predict_type = "prob")

# fit these learners using cv5 
res_tel1 <- benchmark(data.table(
  task       = list(telecom_task),
  learner    = list(lrn_baseline_tel,
                    lrn_cart_tel),
  resampling = list(cv5,cv5)
  ), store_models = TRUE)

# show multiple of these measures:
res_tel1$aggregate(list(msr("classif.ce"),
                   msr("classif.acc"),
                   msr("classif.auc"),
                   msr("classif.fpr"),
                   msr("classif.fnr")))

# doing *nested* cross validation for 'rpart' model:
lrn_cart_tel_cv <- lrn("classif.rpart", predict_type = "prob", xval = 10)

res_cart__tel_cv5 <- resample(telecom_task, lrn_cart_tel_cv, cv5, store_models = TRUE)

# visualize cross validation plot from each round of this model:
rpart::plotcp(res_cart__tel_cv5$learners[[5]]$model)

# show measurements of this model #
res_cart__tel_cv5$aggregate(list(msr("classif.ce"),
                                 msr("classif.acc"),
                                 msr("classif.auc"),
                                 msr("classif.fpr"),
                                 msr("classif.fnr")))



# Try to fit a XGBOOST model and deal with encoding,
# this may takes around 5 minutes to get the result:
set.seed(20)
library('xgboost')
# Create a pipeline which encodes and then fits a XGBOOST model
lrn_xgboost_tel <- lrn("classif.xgboost", predict_type = "prob")
pl_xgb_tel <- po("encode") %>>%
  po(lrn_xgboost_tel)

res_tel3 <- benchmark(data.table(
  task       = list(telecom_task),
  learner    = list(pl_xgb_tel),
  resampling = list(cv5)
  ), store_models = TRUE)

res_tel3$aggregate(list(msr("classif.ce"),
                   msr("classif.acc"),
                   msr("classif.auc"),
                   msr("classif.fpr"),
                   msr("classif.fnr")))


########## Part2: Try to improve 'rpart' and 'xgboost'models above: ############

### try to improve a 'rpart' model:
lrn_cart_tel_cp <- lrn("classif.rpart", predict_type = "prob", cp = 3)

res_tel2 <- benchmark(data.table(
  task       = list(telecom_task),
  learner    = list(lrn_cart_tel_cp),
  resampling = list(cv5)
), store_models = TRUE)

res_tel2$aggregate(list(msr("classif.ce"),
                        msr("classif.acc"),
                        msr("classif.auc"),
                        msr("classif.fpr"),
                        msr("classif.fnr")))

### try to improve a 'xgoost' model:
set.seed(20)
# Create a pipeline which encodes and then fits a XGBOOST model
lrn_xgboost_tel_ip <- lrn("classif.xgboost", predict_type = "prob",
                          booster="gbtree",eta=0.01,max_depth=5,subsample=1,
                          colsample_bylevel=1)
pl_xgb_tel_ip <- po("encode") %>>%
  po(lrn_xgboost_tel_ip)

res_tel3_ip <- benchmark(data.table(
  task       = list(telecom_task),
  learner    = list(pl_xgb_tel_ip),
  resampling = list(cv5)
), store_models = TRUE)

res_tel3_ip$aggregate(list(msr("classif.ce"),
                        msr("classif.acc"),
                        msr("classif.auc"),
                        msr("classif.fpr"),
                        msr("classif.fnr")))


###############################################################################
################### Try a super learning model ################################
###############################################################################


set.seed(20) # set seed for reproducibility

# Define two new learners:
lrn_cart_cp_tel  <- lrn("classif.rpart", predict_type = "prob", cp = 3, id = "cartcp")
lrn_ranger_tel   <- lrn("classif.ranger", predict_type = "prob")

# Define a super learner using 'xgboost' model:
lrn_xgboost_tel_sp <- lrn("classif.xgboost", predict_type = "prob",
                          booster="gbtree",eta=0.01,max_depth=5,subsample=1,
                          colsample_bylevel=1,id="super")

# Missingness imputation pipeline
pl_missing_tel <- po("fixfactors") %>>%
  po("removeconstants") %>>%
  po("imputesample", affect_columns = selector_type(c("ordered", "factor"))) %>>%
  po("imputemean")

# Factors coding pipeline
pl_factor_tel <- po("encode")

# Now define the full pipeline
spr_lrn_tel <- gunion(list(
  # First group of learners requiring no modification to input
  gunion(list(
    po("learner_cv", lrn_baseline_tel),
    po("learner_cv", lrn_cart_tel),
    po("learner_cv", lrn_cart_cp_tel)
  )),
  # Next group of learners requiring special treatment of missingness
  pl_missing_tel %>>%
    gunion(list(
      po("learner_cv", lrn_ranger_tel)
    )),
  # Last group needing factor encoding
  pl_factor_tel %>>%
    po("learner_cv", lrn_xgboost_tel)
  )) %>>%
  po("featureunion") %>>%
  po(lrn_xgboost_tel_sp)

# This plot shows a graph of the learning pipeline
spr_lrn_tel$plot()

# Finally fit the base learners and super learner and evaluate using cv5,
# this step may takes  5~10 minutes to get the results:
set.seed(20)
res_spr_tel <- resample(telecom_task, spr_lrn_tel, cv5, store_models = TRUE)
res_spr_tel$aggregate(list(msr("classif.ce"),
                       msr("classif.acc"),
                       msr("classif.auc"),
                       msr("classif.fpr"),
                       msr("classif.fnr")))


###############################################################################
################################ Deep Learning ################################
###############################################################################

################# Part1: processing sets for deep learning ###################

library("rsample")
set.seed(20) # by setting the seed we know everyone will see the same results

# First get the training
telecom_split <- initial_split(telecom)
telecom_train <- training(telecom_split)
# Then further split the training into validate and test
telecom_split2 <- initial_split(testing(telecom_split), 0.5)
telecom_validate <- training(telecom_split2)
telecom_test <- testing(telecom_split2)

library("recipes")

cake <- recipe(Churn ~ ., data = telecom) %>%
  step_meanimpute(all_numeric()) %>% # impute missings on numeric values with the mean
  step_center(all_numeric()) %>% # center by subtracting the mean from all numeric features
  step_scale(all_numeric()) %>% # scale by dividing by the standard deviation on all numeric features
  step_unknown(all_nominal(), -all_outcomes()) %>% # create a new factor level called "unknown" to account for NAs in factors, except for the outcome (response can't be NA)
  step_dummy(all_nominal(), one_hot = TRUE) %>% # turn all factors into a one-hot coding
  prep(training = telecom_train) # learn all the parameters of preprocessing on the training data

telecom_train_final <- bake(cake, new_data = telecom_train) # apply preprocessing to training data
telecom_validate_final <- bake(cake, new_data = telecom_validate) # apply preprocessing to validation data
telecom_test_final <- bake(cake, new_data = telecom_test) # apply preprocessing to testing data

library("keras")

telecom_train_x <- telecom_train_final %>%
  select(-starts_with("Churn_")) %>%
  as.matrix()
telecom_train_y <- telecom_train_final %>%
  select(Churn_No) %>%
  as.matrix()

telecom_validate_x <- telecom_validate_final %>%
  select(-starts_with("Churn_")) %>%
  as.matrix()
telecom_validate_y <- telecom_validate_final %>%
  select(Churn_No) %>%
  as.matrix()

telecom_test_x <- telecom_test_final %>%
  select(-starts_with("Churn_")) %>%
  as.matrix()
telecom_test_y <- telecom_test_final %>%
  select(Churn_No) %>%
  as.matrix()

############### Part2: Try deep learning with simple structure ################
set.seed(20)
deep.net1 <- keras_model_sequential() %>%
  layer_dense(units = 4, activation = "relu",
              input_shape = c(ncol(telecom_train_x))) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")
# Have a look at it
deep.net1

# compile the network
deep.net1 %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(),
  metrics = c("accuracy")
)

# fit the neural network
deep.net1 %>% fit(
  telecom_train_x, telecom_train_y,
  epochs = 50, batch_size = 32,
  validation_data = list(telecom_validate_x, telecom_validate_y),
)

# To get the probability predictions on the test set:
pred_test_prob1 <- deep.net1 %>% predict_proba(telecom_test_x)

# To get the raw classes (assuming 0.5 cutoff):
pred_test_res1 <- deep.net1 %>% predict_classes(telecom_test_x)

# Confusion matrix/accuracy/AUC metrics
table(pred_test_res1, telecom_test_y)
yardstick::accuracy_vec(as.factor(telecom_test_y),
                        as.factor(pred_test_res1))
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob1))

# calculate the fpr and fnr
fpr1<-sum(telecom_test_y==1 & pred_test_res1==0)/sum(telecom_test_y==1)
fnr1<-sum(telecom_test_y==0 & pred_test_res1==1)/sum(telecom_test_y==0)
fpr1
fnr1

######### Part3: Try deep learning with deeper and broader structure ##########

deep.net2 <- keras_model_sequential() %>%
  layer_dense(units = 8, activation = "relu",
              input_shape = c(ncol(telecom_train_x))) %>%
  layer_dense(units = 8, activation = "relu") %>%
  layer_dense(units = 8, activation = "relu") %>%
  layer_dense(units = 8, activation = "relu") %>%
  layer_dense(units = 8, activation = "relu") %>%
  layer_dense(units = 8, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")
# Have a look at it
deep.net2

deep.net2 %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(),
  metrics = c("accuracy")
)

deep.net2 %>% fit(
  telecom_train_x, telecom_train_y,
  epochs = 50, batch_size = 32,
  validation_data = list(telecom_validate_x, telecom_validate_y),
)
# To get the probability predictions on the test set:
pred_test_prob2 <- deep.net2 %>% predict_proba(telecom_test_x)

# To get the raw classes (assuming 0.5 cutoff):
pred_test_res2 <- deep.net2 %>% predict_classes(telecom_test_x)

# Confusion matrix/accuracy/AUC metrics
table(pred_test_res2, telecom_test_y)
yardstick::accuracy_vec(as.factor(telecom_test_y),
                        as.factor(pred_test_res2))
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob2))

# calculate the fpr and fnr
fpr2<-sum(telecom_test_y==1 & pred_test_res2==0)/sum(telecom_test_y==1)
fnr2<-sum(telecom_test_y==0 & pred_test_res2==1)/sum(telecom_test_y==0)
fpr2
fnr2

############### Part4: Try to optimize deep learning model ####################

## The final chosen model: ##
deep.net3 <- keras_model_sequential() %>%
    layer_dense(units = 4, activation = "relu",
                input_shape = c(ncol(telecom_train_x))) %>%
    layer_batch_normalization() %>%
    layer_dropout(rate = 0.5) %>%
    layer_dense(units = 4, activation = "relu") %>%
    layer_batch_normalization() %>%
    layer_dropout(rate = 0.5) %>%
    layer_dense(units = 4, activation = "relu") %>%
    layer_batch_normalization() %>%
    layer_dropout(rate = 0.5) %>%
    layer_dense(units = 4, activation = "relu") %>%
    layer_batch_normalization() %>%
    layer_dropout(rate = 0.5) %>%
    layer_dense(units = 1, activation = "sigmoid")
# Have a look at it
deep.net3

deep.net3 %>% compile(
     loss = "binary_crossentropy",
     optimizer = optimizer_rmsprop(),
     metrics = c("accuracy")
   )
 
deep.net3 %>% fit(
      telecom_train_x, telecom_train_y,
      epochs = 50, batch_size = 32,
      validation_data = list(telecom_validate_x, telecom_validate_y),
    )
# To get the probability predictions on the test set:
pred_test_prob3 <- deep.net3 %>% predict_proba(telecom_test_x)

# To get the raw classes (assuming 0.5 cutoff):
pred_test_res3 <- deep.net3 %>% predict_classes(telecom_test_x)

# Confusion matrix/accuracy/AUC metrics
table(pred_test_res3, telecom_test_y)
yardstick::accuracy_vec(as.factor(telecom_test_y),
                        as.factor(pred_test_res3))
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob3))

# calculate the fpr and fnr
fpr3<-sum(telecom_test_y==1 & pred_test_res3==0)/sum(telecom_test_y==1)
fnr3<-sum(telecom_test_y==0 & pred_test_res3==1)/sum(telecom_test_y==0)
fpr3
fnr3

## if the dropout of input layer is 0.2 ##
deep.net4 <- keras_model_sequential() %>%
  layer_dense(units = 4, activation = "relu",
              input_shape = c(ncol(telecom_train_x))) %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.2) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 1, activation = "sigmoid")
# Have a look at it
deep.net4

deep.net4 %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(),
  metrics = c("accuracy")
)

deep.net4 %>% fit(
  telecom_train_x, telecom_train_y,
  epochs = 50, batch_size = 32,
  validation_data = list(telecom_validate_x, telecom_validate_y),
)
# To get the probability predictions on the test set:
pred_test_prob4 <- deep.net4 %>% predict_proba(telecom_test_x)

# To get the raw classes (assuming 0.5 cutoff):
pred_test_res4 <- deep.net4 %>% predict_classes(telecom_test_x)

# Confusion matrix/accuracy/AUC metrics
table(pred_test_res4, telecom_test_y)
yardstick::accuracy_vec(as.factor(telecom_test_y),
                        as.factor(pred_test_res4))
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob4))

# calculate the fpr and fnr
fpr4<-sum(telecom_test_y==1 & pred_test_res4==0)/sum(telecom_test_y==1)
fnr4<-sum(telecom_test_y==0 & pred_test_res4==1)/sum(telecom_test_y==0)
fpr4
fnr4

## try 'tanh' activation function ##
deep.net5 <- keras_model_sequential() %>%
  layer_dense(units = 4, activation = "relu",
              input_shape = c(ncol(telecom_train_x))) %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 1, activation = "tanh")
# Have a look at it
deep.net5

deep.net5 %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(),
  metrics = c("accuracy")
)

deep.net5 %>% fit(
  telecom_train_x, telecom_train_y,
  epochs = 50, batch_size = 32,
  validation_data = list(telecom_validate_x, telecom_validate_y),
)
# To get the probability predictions on the test set:
pred_test_prob5 <- deep.net5 %>% predict_proba(telecom_test_x)

# To get the raw classes (assuming 0.5 cutoff):
pred_test_res5 <- deep.net5 %>% predict_classes(telecom_test_x)

# Confusion matrix/accuracy/AUC metrics
table(pred_test_res5, telecom_test_y)
yardstick::accuracy_vec(as.factor(telecom_test_y),
                        as.factor(pred_test_res5))
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob5))

# calculate the fpr and fnr
fpr5<-sum(telecom_test_y==1 & pred_test_res5==0)/sum(telecom_test_y==1)
fnr5<-sum(telecom_test_y==0 & pred_test_res5==1)/sum(telecom_test_y==0)
fpr5
fnr5

## try Adam optimizer ##
deep.net6 <- keras_model_sequential() %>%
  layer_dense(units = 4, activation = "relu",
              input_shape = c(ncol(telecom_train_x))) %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 4, activation = "relu") %>%
  layer_batch_normalization() %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 1, activation = "sigmoid")
# Have a look at it
deep.net6

deep.net6 %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_adam(),
  metrics = c("accuracy")
)

deep.net6 %>% fit(
  telecom_train_x, telecom_train_y,
  epochs = 50, batch_size = 32,
  validation_data = list(telecom_validate_x, telecom_validate_y),
)
# To get the probability predictions on the test set:
pred_test_prob6 <- deep.net6 %>% predict_proba(telecom_test_x)

# To get the raw classes (assuming 0.5 cutoff):
pred_test_res6 <- deep.net6 %>% predict_classes(telecom_test_x)

# Confusion matrix/accuracy/AUC metrics
table(pred_test_res6, telecom_test_y)
yardstick::accuracy_vec(as.factor(telecom_test_y),
                        as.factor(pred_test_res6))
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob6))

# calculate the fpr and fnr
fpr6<-sum(telecom_test_y==1 & pred_test_res6==0)/sum(telecom_test_y==1)
fnr6<-sum(telecom_test_y==0 & pred_test_res6==1)/sum(telecom_test_y==0)
fpr6
fnr6


###############################################################################
################################ Random Forest ################################
###############################################################################

telecom_rf<-read.csv("telecom.csv")

# find where exists missings
find.missing<-matrix(0,1,20)

for (j in 1:loops){
  find.missing[1,j]<-sum(is.na(telecom_rf[,j])==TRUE)
}
find.missing # show by this matrix, column 19 misses 10 values

where.missing<-which(is.na(telecom_rf[,19]==TRUE))

# substitute these missings with mean value of this column
sum.value<-0
for (k in 1:length(telecom_rf[,19])){
  if (sum((k==where.missing)==TRUE)==0){
    sum.value = sum.value + telecom_rf[,19][k]
  }
}
mean.value<-sum.value/(length(telecom_rf[,19])-10) # calculate mean value of this column

telecom_rf[where.missing,19]<-mean.value


telecom_rf<-telecom_rf%>%
  mutate(Senior_Citizen=case_when(
    SeniorCitizen==0~'No',
    TRUE~"Yes"
  ))%>%
  select(-SeniorCitizen)

for (m in 1:loops){
  telecom_rf[,m]<-as.factor(telecom_rf[,m])
}

# random forest
set.seed(20)
rf_tel <- ranger::ranger(as.factor(Churn) ~ ., telecom_rf[1:4490,])
predrf_tel <- predict(rf_tel, telecom_rf[5239:5986,])

# process test set
telecom_test_y2 <- nnet::class.ind(telecom_rf[5239:5986,"Churn"])
telecom_test_y2<-max.col(telecom_test_y2)-1
telecom_test_y2[which(telecom_test_y2==1)]<-"Yes"
telecom_test_y2[which(telecom_test_y2==0)]<-"No"
telecom_test_y2<-as.factor(telecom_test_y2)


# Confusion matrix/accuracy 
table(predrf_tel$predictions, telecom_test_y2)
yardstick::accuracy_vec(as.factor(telecom_test_y2),
                        predrf_tel$predictions)
yardstick::roc_auc_vec(factor(telecom_test_y, levels = c("1","0")),
                       c(pred_test_prob3))


# calculate the fpr and fnr
fpr_rf<-sum(telecom_test_y2=="No" & predrf_tel$predictions=="Yes")/sum(telecom_test_y2=="No")
fnr_rf<-sum(telecom_test_y2=="Yes" & predrf_tel$predictions=="No")/sum(telecom_test_y2=="Yes")
fpr_rf
fnr_rf




























